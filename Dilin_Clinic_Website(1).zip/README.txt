DILIN CLINIC WEBSITE
====================

Files:
- index.html: complete responsive trilingual static website (Arabic, Sorani Kurdish, English).

RENDER SETTINGS
---------------
Create a "Static Site" in Render and select the GitHub repository:
jalalleath-afk / Dilin
Branch: main

For this plain HTML website:
- Root Directory: leave blank
- Build Command: leave blank
- Publish Directory: .

Then click "Create Static Site". Render will publish the site and show its public URL.

UPLOAD FROM A PHONE
-------------------
1. Open https://github.com/jalalleath-afk/Dilin
2. Sign in to GitHub.
3. Choose Add file > Upload files.
4. Upload index.html from this folder.
5. Scroll down and choose Commit changes.
6. Return to Render and select/redeploy the Static Site.

IMPORTANT
---------
The clinic phone number and street address have not yet been provided, so the website currently shows a note where these details will go. Send the exact phone/WhatsApp number and clinic address to add them. No medical claims, prices, or unconfirmed services have been invented.
